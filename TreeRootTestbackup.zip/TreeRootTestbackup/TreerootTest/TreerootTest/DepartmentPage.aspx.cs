﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace TreerootTest
{
    public partial class DepartmentPage : System.Web.UI.Page
    {
        string constr = ConfigurationManager.ConnectionStrings["cnstr"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                ShowDepartentList();
            }
        }

        public void ShowDepartentList()
        {
            SqlConnection sqlconnection = new SqlConnection(constr);
            sqlconnection.Open();
            SqlDataAdapter sqldataadapter = new SqlDataAdapter("spgetDepartmentlist", sqlconnection);
            sqldataadapter.SelectCommand.CommandType = CommandType.StoredProcedure;
            DataTable datatable = new DataTable();
            sqldataadapter.Fill(datatable);
            grdDepartment.DataSource = datatable;
            grdDepartment.DataBind();


        }
    }
}