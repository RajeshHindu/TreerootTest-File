﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace TreerootTest
{
    public partial class EmployeePage : System.Web.UI.Page
    {
        string constr = ConfigurationManager.ConnectionStrings["cnstr"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                populateDropdowwnlist();
                Calendar1.Visible = false;
                Calendar2.Visible = false;
                showdata();
            }
        }

        public void populateDropdowwnlist()
        {
            SqlConnection sqlconnection = new SqlConnection(constr);
            sqlconnection.Open();
            SqlCommand cmd = new SqlCommand("spgetDepartmentlist", sqlconnection);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            ddlDepartment.DataSource = cmd.ExecuteReader();
            ddlDepartment.DataTextField = "Name";
            ddlDepartment.DataValueField = "Id";
            ddlDepartment.DataBind();
            ddlDepartment.Items.Insert(0, "Select");
        }



        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            txtdob.Text = Calendar1.SelectedDate.ToString("d");
            Calendar1.Visible = false;
        }

        protected void imgbtn_Click(object sender, ImageClickEventArgs e)
        {
            if(Calendar1.Visible)
            {
                Calendar1.Visible = false;
            }
            else
            {
                Calendar1.Visible = true;
            }
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar2.Visible)
            {
                Calendar2.Visible = false;
            }
            else
            {
                Calendar2.Visible = true;
            }
        }

        protected void Calendar2_SelectionChanged(object sender, EventArgs e)
        {
            txtdateofjoin.Text = Calendar2.SelectedDate.ToString("d");
            Calendar2.Visible = false;
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(constr))
            {

                SqlCommand cmd = new SqlCommand("SpSaveEmployee", con);

                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.AddWithValue("@FirstName", txtFname.Text.ToString());
                cmd.Parameters.AddWithValue("@LastName", txtLname.Text.ToString());
                cmd.Parameters.AddWithValue("@DOB", txtdob.Text.ToString());
                cmd.Parameters.AddWithValue("@DateOfJoin", txtdateofjoin.Text.ToString());
                cmd.Parameters.AddWithValue("@Departmentid", ddlDepartment.SelectedValue);
                cmd.Parameters.AddWithValue("@IsActive", 1);
                cmd.ExecuteNonQuery();
                showdata();
           

            }
        }

        public void showdata()
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
                // con.Open();
                SqlCommand cmd = new SqlCommand("SpGetEmployee", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                con.Open();

                grdEmployee.DataSource = cmd.ExecuteReader();
                grdEmployee.DataBind();


            }


        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(constr))
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("SpUpdateEmployee", con);
                cmd.CommandType = CommandType.StoredProcedure;
                int Id = Convert.ToInt32(Session["Id"]);

                cmd.Parameters.AddWithValue("@FirstName", txtFname.Text.ToString());
                cmd.Parameters.AddWithValue("@LastName", txtLname.Text.ToString());
                cmd.Parameters.AddWithValue("@DOB", txtdob.Text.ToString());
                cmd.Parameters.AddWithValue("@DateOfJoin", txtdateofjoin.Text.ToString());
                cmd.Parameters.AddWithValue("@Departmentid", ddlDepartment.SelectedValue);
                cmd.Parameters.AddWithValue("@Id", Id);

                cmd.ExecuteNonQuery();
                showdata();
              
            }
        }

        protected void btnView_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(constr))
            {
                int id = Convert.ToInt16((sender as LinkButton).CommandArgument);

                con.Open();
                SqlDataAdapter adptr = new SqlDataAdapter("SpGetEmployeeById", con);
                adptr.SelectCommand.CommandType = CommandType.StoredProcedure;
                adptr.SelectCommand.Parameters.AddWithValue("@Id", id);
                DataTable dt = new DataTable();
                adptr.Fill(dt);
                txtFname.Text = dt.Rows[0]["FirstName"].ToString();
                txtLname.Text = dt.Rows[0]["LastName"].ToString();
                txtdob.Text = dt.Rows[0]["DOB"].ToString();
                txtdateofjoin.Text = dt.Rows[0]["DateOfJoin"].ToString();
            
                ddlDepartment.ClearSelection();
                string selectedText = dt.Rows[0]["Name"].ToString();
                ddlDepartment.Items.FindByText(selectedText).Selected = true;
                //ddlCategoryName.SelectedItem.Text = dt.Rows[0]["Category_Name"].ToString();
                Session["Id"] = id;


            }
        }

        protected void grdEmployee_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            GridViewRow row = grdEmployee.Rows[e.RowIndex];
            int id = Convert.ToInt32(grdEmployee.DataKeys[e.RowIndex].Values[0]);
            //TextBox Category_Name = (TextBox)row.Cells[0].Controls[0];

            using (SqlConnection con = new SqlConnection(constr))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SpDeleteEmployee", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.ExecuteNonQuery();
                grdEmployee.EditIndex = -1;
                this.showdata();
            }
        }
    }
}